const SONGS = [
  {
    "id": 1,
    "title": "La Bamba",
    "artist": "Ritchie Valens",
    "year": 1958,
    "genre": "Rock & Roll",
    "language": "Inglés/Español",
    "decade": "1950s",
    "spotify": "https://open.spotify.com/search/La%20Bamba%20Ritchie%20Valens"
  },
  {
    "id": 2,
    "title": "Twist and Shout",
    "artist": "The Beatles",
    "year": 1963,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Twist%20and%20Shout%20The%20Beatles"
  },
  {
    "id": 3,
    "title": "Oh, Pretty Woman",
    "artist": "Roy Orbison",
    "year": 1964,
    "genre": "Rock & Roll",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Oh%2C%20Pretty%20Woman%20Roy%20Orbison"
  },
  {
    "id": 4,
    "title": "Satisfaction",
    "artist": "The Rolling Stones",
    "year": 1965,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Satisfaction%20The%20Rolling%20Stones"
  },
  {
    "id": 5,
    "title": "Respect",
    "artist": "Aretha Franklin",
    "year": 1967,
    "genre": "Soul",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Respect%20Aretha%20Franklin"
  },
  {
    "id": 6,
    "title": "Hey Jude",
    "artist": "The Beatles",
    "year": 1968,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Hey%20Jude%20The%20Beatles"
  },
  {
    "id": 7,
    "title": "Suspicious Minds",
    "artist": "Elvis Presley",
    "year": 1969,
    "genre": "Rock & Roll",
    "language": "Inglés",
    "decade": "1960s",
    "spotify": "https://open.spotify.com/search/Suspicious%20Minds%20Elvis%20Presley"
  },
  {
    "id": 8,
    "title": "Imagine",
    "artist": "John Lennon",
    "year": 1971,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Imagine%20John%20Lennon"
  },
  {
    "id": 9,
    "title": "Let's Stay Together",
    "artist": "Al Green",
    "year": 1971,
    "genre": "Soul",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Let%27s%20Stay%20Together%20Al%20Green"
  },
  {
    "id": 10,
    "title": "Superstition",
    "artist": "Stevie Wonder",
    "year": 1972,
    "genre": "Funk/Soul",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Superstition%20Stevie%20Wonder"
  },
  {
    "id": 11,
    "title": "Dream On",
    "artist": "Aerosmith",
    "year": 1973,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Dream%20On%20Aerosmith"
  },
  {
    "id": 12,
    "title": "El Triste",
    "artist": "José José",
    "year": 1970,
    "genre": "Balada",
    "language": "Español",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/El%20Triste%20Jos%C3%A9%20Jos%C3%A9"
  },
  {
    "id": 13,
    "title": "Querida",
    "artist": "Juan Gabriel",
    "year": 1984,
    "genre": "Balada",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Querida%20Juan%20Gabriel"
  },
  {
    "id": 14,
    "title": "Bohemian Rhapsody",
    "artist": "Queen",
    "year": 1975,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Bohemian%20Rhapsody%20Queen"
  },
  {
    "id": 15,
    "title": "Hotel California",
    "artist": "Eagles",
    "year": 1976,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Hotel%20California%20Eagles"
  },
  {
    "id": 16,
    "title": "Dancing Queen",
    "artist": "ABBA",
    "year": 1976,
    "genre": "Pop/Disco",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Dancing%20Queen%20ABBA"
  },
  {
    "id": 17,
    "title": "Stayin' Alive",
    "artist": "Bee Gees",
    "year": 1977,
    "genre": "Disco",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Stayin%27%20Alive%20Bee%20Gees"
  },
  {
    "id": 18,
    "title": "We Will Rock You",
    "artist": "Queen",
    "year": 1977,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/We%20Will%20Rock%20You%20Queen"
  },
  {
    "id": 19,
    "title": "September",
    "artist": "Earth, Wind & Fire",
    "year": 1978,
    "genre": "Disco/Funk",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/September%20Earth%2C%20Wind%20%26%20Fire"
  },
  {
    "id": 20,
    "title": "I Will Survive",
    "artist": "Gloria Gaynor",
    "year": 1978,
    "genre": "Disco",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/I%20Will%20Survive%20Gloria%20Gaynor"
  },
  {
    "id": 21,
    "title": "Another Brick in the Wall, Pt. 2",
    "artist": "Pink Floyd",
    "year": 1979,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Another%20Brick%20in%20the%20Wall%2C%20Pt.%202%20Pink%20Floyd"
  },
  {
    "id": 22,
    "title": "Bette Davis Eyes",
    "artist": "Kim Carnes",
    "year": 1981,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Bette%20Davis%20Eyes%20Kim%20Carnes"
  },
  {
    "id": 23,
    "title": "Don't Stop Believin'",
    "artist": "Journey",
    "year": 1981,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Don%27t%20Stop%20Believin%27%20Journey"
  },
  {
    "id": 24,
    "title": "Eye of the Tiger",
    "artist": "Survivor",
    "year": 1982,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Eye%20of%20the%20Tiger%20Survivor"
  },
  {
    "id": 25,
    "title": "Billie Jean",
    "artist": "Michael Jackson",
    "year": 1983,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Billie%20Jean%20Michael%20Jackson"
  },
  {
    "id": 26,
    "title": "Girls Just Want to Have Fun",
    "artist": "Cyndi Lauper",
    "year": 1983,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Girls%20Just%20Want%20to%20Have%20Fun%20Cyndi%20Lauper"
  },
  {
    "id": 27,
    "title": "Sweet Dreams (Are Made of This)",
    "artist": "Eurythmics",
    "year": 1983,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Sweet%20Dreams%20%28Are%20Made%20of%20This%29%20Eurythmics"
  },
  {
    "id": 28,
    "title": "Take on Me",
    "artist": "a-ha",
    "year": 1985,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Take%20on%20Me%20a-ha"
  },
  {
    "id": 29,
    "title": "Livin' on a Prayer",
    "artist": "Bon Jovi",
    "year": 1986,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Livin%27%20on%20a%20Prayer%20Bon%20Jovi"
  },
  {
    "id": 30,
    "title": "Persiana Americana",
    "artist": "Soda Stereo",
    "year": 1986,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Persiana%20Americana%20Soda%20Stereo"
  },
  {
    "id": 31,
    "title": "Devuélveme a mi chica",
    "artist": "Hombres G",
    "year": 1985,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Devu%C3%A9lveme%20a%20mi%20chica%20Hombres%20G"
  },
  {
    "id": 32,
    "title": "Cuando pase el temblor",
    "artist": "Soda Stereo",
    "year": 1985,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Cuando%20pase%20el%20temblor%20Soda%20Stereo"
  },
  {
    "id": 33,
    "title": "La Muralla Verde",
    "artist": "Enanitos Verdes",
    "year": 1986,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/La%20Muralla%20Verde%20Enanitos%20Verdes"
  },
  {
    "id": 34,
    "title": "Cómo te va mi amor",
    "artist": "Pandora",
    "year": 1985,
    "genre": "Balada",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/C%C3%B3mo%20te%20va%20mi%20amor%20Pandora"
  },
  {
    "id": 35,
    "title": "Ahora te puedes marchar",
    "artist": "Luis Miguel",
    "year": 1987,
    "genre": "Pop",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Ahora%20te%20puedes%20marchar%20Luis%20Miguel"
  },
  {
    "id": 36,
    "title": "La Incondicional",
    "artist": "Luis Miguel",
    "year": 1988,
    "genre": "Balada",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/La%20Incondicional%20Luis%20Miguel"
  },
  {
    "id": 37,
    "title": "Mujer contra mujer",
    "artist": "Mecano",
    "year": 1988,
    "genre": "Pop",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Mujer%20contra%20mujer%20Mecano"
  },
  {
    "id": 38,
    "title": "Nothing's Gonna Stop Us Now",
    "artist": "Starship",
    "year": 1987,
    "genre": "Pop/Rock",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Nothing%27s%20Gonna%20Stop%20Us%20Now%20Starship"
  },
  {
    "id": 39,
    "title": "Sweet Child o' Mine",
    "artist": "Guns N' Roses",
    "year": 1987,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Sweet%20Child%20o%27%20Mine%20Guns%20N%27%20Roses"
  },
  {
    "id": 40,
    "title": "Like a Prayer",
    "artist": "Madonna",
    "year": 1989,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Like%20a%20Prayer%20Madonna"
  },
  {
    "id": 41,
    "title": "Lobo-Hombre en París",
    "artist": "La Unión",
    "year": 1984,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1980s",
    "spotify": "https://open.spotify.com/search/Lobo-Hombre%20en%20Par%C3%ADs%20La%20Uni%C3%B3n"
  },
  {
    "id": 42,
    "title": "Entre dos tierras",
    "artist": "Héroes del Silencio",
    "year": 1990,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Entre%20dos%20tierras%20H%C3%A9roes%20del%20Silencio"
  },
  {
    "id": 43,
    "title": "Rayando el Sol",
    "artist": "Maná",
    "year": 1990,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Rayando%20el%20Sol%20Man%C3%A1"
  },
  {
    "id": 44,
    "title": "De música ligera",
    "artist": "Soda Stereo",
    "year": 1990,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/De%20m%C3%BAsica%20ligera%20Soda%20Stereo"
  },
  {
    "id": 45,
    "title": "Vogue",
    "artist": "Madonna",
    "year": 1990,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Vogue%20Madonna"
  },
  {
    "id": 46,
    "title": "Smells Like Teen Spirit",
    "artist": "Nirvana",
    "year": 1991,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Smells%20Like%20Teen%20Spirit%20Nirvana"
  },
  {
    "id": 47,
    "title": "Losing My Religion",
    "artist": "R.E.M.",
    "year": 1991,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Losing%20My%20Religion%20R.E.M."
  },
  {
    "id": 48,
    "title": "Mi historia entre tus dedos",
    "artist": "Gianluca Grignani",
    "year": 1994,
    "genre": "Balada",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Mi%20historia%20entre%20tus%20dedos%20Gianluca%20Grignani"
  },
  {
    "id": 49,
    "title": "Amor Prohibido",
    "artist": "Selena",
    "year": 1994,
    "genre": "Regional/Tejano",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Amor%20Prohibido%20Selena"
  },
  {
    "id": 50,
    "title": "La Chona",
    "artist": "Los Tucanes de Tijuana",
    "year": 1995,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/La%20Chona%20Los%20Tucanes%20de%20Tijuana"
  },
  {
    "id": 51,
    "title": "Lamento Boliviano",
    "artist": "Enanitos Verdes",
    "year": 1994,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Lamento%20Boliviano%20Enanitos%20Verdes"
  },
  {
    "id": 52,
    "title": "La Flaca",
    "artist": "Jarabe de Palo",
    "year": 1996,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/La%20Flaca%20Jarabe%20de%20Palo"
  },
  {
    "id": 53,
    "title": "En el muelle de San Blas",
    "artist": "Maná",
    "year": 1997,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/En%20el%20muelle%20de%20San%20Blas%20Man%C3%A1"
  },
  {
    "id": 54,
    "title": "Vuela Vuela",
    "artist": "Magneto",
    "year": 1991,
    "genre": "Pop",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Vuela%20Vuela%20Magneto"
  },
  {
    "id": 55,
    "title": "Pelo Suelto",
    "artist": "Gloria Trevi",
    "year": 1991,
    "genre": "Pop/Rock",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Pelo%20Suelto%20Gloria%20Trevi"
  },
  {
    "id": 56,
    "title": "No podrás",
    "artist": "Cristian Castro",
    "year": 1992,
    "genre": "Balada",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/No%20podr%C3%A1s%20Cristian%20Castro"
  },
  {
    "id": 57,
    "title": "Azúcar Amargo",
    "artist": "Fey",
    "year": 1996,
    "genre": "Pop",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Az%C3%BAcar%20Amargo%20Fey"
  },
  {
    "id": 58,
    "title": "Oye mi amor",
    "artist": "Maná",
    "year": 1992,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Oye%20mi%20amor%20Man%C3%A1"
  },
  {
    "id": 59,
    "title": "I Want It That Way",
    "artist": "Backstreet Boys",
    "year": 1999,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/I%20Want%20It%20That%20Way%20Backstreet%20Boys"
  },
  {
    "id": 60,
    "title": "...Baby One More Time",
    "artist": "Britney Spears",
    "year": 1998,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/...Baby%20One%20More%20Time%20Britney%20Spears"
  },
  {
    "id": 61,
    "title": "Genie in a Bottle",
    "artist": "Christina Aguilera",
    "year": 1999,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Genie%20in%20a%20Bottle%20Christina%20Aguilera"
  },
  {
    "id": 62,
    "title": "Believe",
    "artist": "Cher",
    "year": 1998,
    "genre": "Pop/Dance",
    "language": "Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Believe%20Cher"
  },
  {
    "id": 63,
    "title": "Corazón Espinado",
    "artist": "Santana feat. Maná",
    "year": 1999,
    "genre": "Rock latino",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Coraz%C3%B3n%20Espinado%20Santana%20feat.%20Man%C3%A1"
  },
  {
    "id": 64,
    "title": "Livin' la Vida Loca",
    "artist": "Ricky Martin",
    "year": 1999,
    "genre": "Pop latino",
    "language": "Español/Inglés",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Livin%27%20la%20Vida%20Loca%20Ricky%20Martin"
  },
  {
    "id": 65,
    "title": "A puro dolor",
    "artist": "Son by Four",
    "year": 2000,
    "genre": "Balada",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/A%20puro%20dolor%20Son%20by%20Four"
  },
  {
    "id": 66,
    "title": "In the End",
    "artist": "Linkin Park",
    "year": 2000,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/In%20the%20End%20Linkin%20Park"
  },
  {
    "id": 67,
    "title": "Yellow",
    "artist": "Coldplay",
    "year": 2000,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Yellow%20Coldplay"
  },
  {
    "id": 68,
    "title": "La Playa",
    "artist": "La Oreja de Van Gogh",
    "year": 2000,
    "genre": "Pop/Rock",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/La%20Playa%20La%20Oreja%20de%20Van%20Gogh"
  },
  {
    "id": 69,
    "title": "Me gustas tú",
    "artist": "Manu Chao",
    "year": 2001,
    "genre": "Pop latino",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Me%20gustas%20t%C3%BA%20Manu%20Chao"
  },
  {
    "id": 70,
    "title": "Whenever, Wherever",
    "artist": "Shakira",
    "year": 2001,
    "genre": "Pop latino",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Whenever%2C%20Wherever%20Shakira"
  },
  {
    "id": 71,
    "title": "Complicated",
    "artist": "Avril Lavigne",
    "year": 2002,
    "genre": "Pop/Rock",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Complicated%20Avril%20Lavigne"
  },
  {
    "id": 72,
    "title": "Entra en mi vida",
    "artist": "Sin Bandera",
    "year": 2001,
    "genre": "Balada",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Entra%20en%20mi%20vida%20Sin%20Bandera"
  },
  {
    "id": 73,
    "title": "Color Esperanza",
    "artist": "Diego Torres",
    "year": 2001,
    "genre": "Pop",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Color%20Esperanza%20Diego%20Torres"
  },
  {
    "id": 74,
    "title": "Eres",
    "artist": "Café Tacvba",
    "year": 2003,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Eres%20Caf%C3%A9%20Tacvba"
  },
  {
    "id": 75,
    "title": "Rosas",
    "artist": "La Oreja de Van Gogh",
    "year": 2003,
    "genre": "Pop",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Rosas%20La%20Oreja%20de%20Van%20Gogh"
  },
  {
    "id": 76,
    "title": "Aquí no es así",
    "artist": "Caifanes",
    "year": 1994,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Aqu%C3%AD%20no%20es%20as%C3%AD%20Caifanes"
  },
  {
    "id": 77,
    "title": "Gasolina",
    "artist": "Daddy Yankee",
    "year": 2004,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Gasolina%20Daddy%20Yankee"
  },
  {
    "id": 78,
    "title": "Mr. Brightside",
    "artist": "The Killers",
    "year": 2003,
    "genre": "Rock",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Mr.%20Brightside%20The%20Killers"
  },
  {
    "id": 79,
    "title": "Yeah!",
    "artist": "Usher feat. Lil Jon & Ludacris",
    "year": 2004,
    "genre": "R&B/Pop",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Yeah%21%20Usher%20feat.%20Lil%20Jon%20%26%20Ludacris"
  },
  {
    "id": 80,
    "title": "Me voy",
    "artist": "Julieta Venegas",
    "year": 2006,
    "genre": "Pop",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Me%20voy%20Julieta%20Venegas"
  },
  {
    "id": 81,
    "title": "Labios Compartidos",
    "artist": "Maná",
    "year": 2006,
    "genre": "Rock en español",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Labios%20Compartidos%20Man%C3%A1"
  },
  {
    "id": 82,
    "title": "Hips Don't Lie",
    "artist": "Shakira feat. Wyclef Jean",
    "year": 2006,
    "genre": "Pop latino",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Hips%20Don%27t%20Lie%20Shakira%20feat.%20Wyclef%20Jean"
  },
  {
    "id": 83,
    "title": "Noviembre sin ti",
    "artist": "Reik",
    "year": 2005,
    "genre": "Balada",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Noviembre%20sin%20ti%20Reik"
  },
  {
    "id": 84,
    "title": "Todo cambió",
    "artist": "Camila",
    "year": 2006,
    "genre": "Balada",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Todo%20cambi%C3%B3%20Camila"
  },
  {
    "id": 85,
    "title": "Umbrella",
    "artist": "Rihanna feat. Jay-Z",
    "year": 2007,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Umbrella%20Rihanna%20feat.%20Jay-Z"
  },
  {
    "id": 86,
    "title": "Viva la Vida",
    "artist": "Coldplay",
    "year": 2008,
    "genre": "Rock/Pop",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Viva%20la%20Vida%20Coldplay"
  },
  {
    "id": 87,
    "title": "Poker Face",
    "artist": "Lady Gaga",
    "year": 2008,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Poker%20Face%20Lady%20Gaga"
  },
  {
    "id": 88,
    "title": "Colgando en tus manos",
    "artist": "Carlos Baute feat. Marta Sánchez",
    "year": 2008,
    "genre": "Pop",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Colgando%20en%20tus%20manos%20Carlos%20Baute%20feat.%20Marta%20S%C3%A1nchez"
  },
  {
    "id": 89,
    "title": "Danza Kuduro",
    "artist": "Don Omar feat. Lucenzo",
    "year": 2010,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Danza%20Kuduro%20Don%20Omar%20feat.%20Lucenzo"
  },
  {
    "id": 90,
    "title": "Rolling in the Deep",
    "artist": "Adele",
    "year": 2010,
    "genre": "Pop/Soul",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Rolling%20in%20the%20Deep%20Adele"
  },
  {
    "id": 91,
    "title": "Corre",
    "artist": "Jesse & Joy",
    "year": 2011,
    "genre": "Balada",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Corre%20Jesse%20%26%20Joy"
  },
  {
    "id": 92,
    "title": "Ai Se Eu Te Pego",
    "artist": "Michel Teló",
    "year": 2011,
    "genre": "Pop latino",
    "language": "Portugués",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Ai%20Se%20Eu%20Te%20Pego%20Michel%20Tel%C3%B3"
  },
  {
    "id": 93,
    "title": "Call Me Maybe",
    "artist": "Carly Rae Jepsen",
    "year": 2011,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Call%20Me%20Maybe%20Carly%20Rae%20Jepsen"
  },
  {
    "id": 94,
    "title": "Locked Out of Heaven",
    "artist": "Bruno Mars",
    "year": 2012,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Locked%20Out%20of%20Heaven%20Bruno%20Mars"
  },
  {
    "id": 95,
    "title": "Get Lucky",
    "artist": "Daft Punk feat. Pharrell Williams",
    "year": 2013,
    "genre": "Pop/Disco",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Get%20Lucky%20Daft%20Punk%20feat.%20Pharrell%20Williams"
  },
  {
    "id": 96,
    "title": "Bailando",
    "artist": "Enrique Iglesias feat. Descemer Bueno & Gente de Zona",
    "year": 2014,
    "genre": "Pop latino",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Bailando%20Enrique%20Iglesias%20feat.%20Descemer%20Bueno%20%26%20Gente%20de%20Zona"
  },
  {
    "id": 97,
    "title": "Uptown Funk",
    "artist": "Mark Ronson feat. Bruno Mars",
    "year": 2014,
    "genre": "Funk/Pop",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Uptown%20Funk%20Mark%20Ronson%20feat.%20Bruno%20Mars"
  },
  {
    "id": 98,
    "title": "Lean On",
    "artist": "Major Lazer & DJ Snake feat. MØ",
    "year": 2015,
    "genre": "Dance",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Lean%20On%20Major%20Lazer%20%26%20DJ%20Snake%20feat.%20M%C3%98"
  },
  {
    "id": 99,
    "title": "Despacito",
    "artist": "Luis Fonsi feat. Daddy Yankee",
    "year": 2017,
    "genre": "Reguetón/Pop",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Despacito%20Luis%20Fonsi%20feat.%20Daddy%20Yankee"
  },
  {
    "id": 100,
    "title": "Felices los 4",
    "artist": "Maluma",
    "year": 2017,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Felices%20los%204%20Maluma"
  },
  {
    "id": 101,
    "title": "Tusa",
    "artist": "Karol G & Nicki Minaj",
    "year": 2019,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Tusa%20Karol%20G%20%26%20Nicki%20Minaj"
  },
  {
    "id": 102,
    "title": "Blinding Lights",
    "artist": "The Weeknd",
    "year": 2019,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Blinding%20Lights%20The%20Weeknd"
  },
  {
    "id": 103,
    "title": "Don't Start Now",
    "artist": "Dua Lipa",
    "year": 2019,
    "genre": "Pop/Disco",
    "language": "Inglés",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Don%27t%20Start%20Now%20Dua%20Lipa"
  },
  {
    "id": 104,
    "title": "Todo de ti",
    "artist": "Rauw Alejandro",
    "year": 2021,
    "genre": "Reguetón/Pop",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Todo%20de%20ti%20Rauw%20Alejandro"
  },
  {
    "id": 105,
    "title": "As It Was",
    "artist": "Harry Styles",
    "year": 2022,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/As%20It%20Was%20Harry%20Styles"
  },
  {
    "id": 106,
    "title": "Tití Me Preguntó",
    "artist": "Bad Bunny",
    "year": 2022,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Tit%C3%AD%20Me%20Pregunt%C3%B3%20Bad%20Bunny"
  },
  {
    "id": 107,
    "title": "Provenza",
    "artist": "Karol G",
    "year": 2022,
    "genre": "Reguetón",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Provenza%20Karol%20G"
  },
  {
    "id": 108,
    "title": "Que vuelvas",
    "artist": "Carín León & Grupo Frontera",
    "year": 2022,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Que%20vuelvas%20Car%C3%ADn%20Le%C3%B3n%20%26%20Grupo%20Frontera"
  },
  {
    "id": 109,
    "title": "Ella Baila Sola",
    "artist": "Eslabon Armado & Peso Pluma",
    "year": 2023,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Ella%20Baila%20Sola%20Eslabon%20Armado%20%26%20Peso%20Pluma"
  },
  {
    "id": 110,
    "title": "Flowers",
    "artist": "Miley Cyrus",
    "year": 2023,
    "genre": "Pop",
    "language": "Inglés",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Flowers%20Miley%20Cyrus"
  },
  {
    "id": 111,
    "title": "Según Quién",
    "artist": "Maluma & Carín León",
    "year": 2023,
    "genre": "Regional/Pop",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Seg%C3%BAn%20Qui%C3%A9n%20Maluma%20%26%20Car%C3%ADn%20Le%C3%B3n"
  },
  {
    "id": 112,
    "title": "Primera Cita",
    "artist": "Carín León",
    "year": 2022,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Primera%20Cita%20Car%C3%ADn%20Le%C3%B3n"
  },
  {
    "id": 113,
    "title": "El Rey",
    "artist": "Vicente Fernández",
    "year": 1976,
    "genre": "Mariachi",
    "language": "Español",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/El%20Rey%20Vicente%20Fern%C3%A1ndez"
  },
  {
    "id": 114,
    "title": "Volver, Volver",
    "artist": "Vicente Fernández",
    "year": 1972,
    "genre": "Mariachi",
    "language": "Español",
    "decade": "1970s",
    "spotify": "https://open.spotify.com/search/Volver%2C%20Volver%20Vicente%20Fern%C3%A1ndez"
  },
  {
    "id": 115,
    "title": "Acá Entre Nos",
    "artist": "Vicente Fernández",
    "year": 1992,
    "genre": "Mariachi",
    "language": "Español",
    "decade": "1990s",
    "spotify": "https://open.spotify.com/search/Ac%C3%A1%20Entre%20Nos%20Vicente%20Fern%C3%A1ndez"
  },
  {
    "id": 116,
    "title": "Eso y Más",
    "artist": "Joan Sebastian",
    "year": 2006,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Eso%20y%20M%C3%A1s%20Joan%20Sebastian"
  },
  {
    "id": 117,
    "title": "Estos Celos",
    "artist": "Vicente Fernández",
    "year": 2007,
    "genre": "Mariachi",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/Estos%20Celos%20Vicente%20Fern%C3%A1ndez"
  },
  {
    "id": 118,
    "title": "Mátalas",
    "artist": "Alejandro Fernández",
    "year": 2003,
    "genre": "Mariachi",
    "language": "Español",
    "decade": "2000s",
    "spotify": "https://open.spotify.com/search/M%C3%A1talas%20Alejandro%20Fern%C3%A1ndez"
  },
  {
    "id": 119,
    "title": "Adiós Amor",
    "artist": "Christian Nodal",
    "year": 2017,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2010s",
    "spotify": "https://open.spotify.com/search/Adi%C3%B3s%20Amor%20Christian%20Nodal"
  },
  {
    "id": 120,
    "title": "Ya Supérame",
    "artist": "Grupo Firme",
    "year": 2021,
    "genre": "Regional mexicano",
    "language": "Español",
    "decade": "2020s",
    "spotify": "https://open.spotify.com/search/Ya%20Sup%C3%A9rame%20Grupo%20Firme"
  }
];
