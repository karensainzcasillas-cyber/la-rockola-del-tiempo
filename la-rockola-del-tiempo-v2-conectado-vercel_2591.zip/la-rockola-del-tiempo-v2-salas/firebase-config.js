window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAs5xP8lCVpYpy1M241XCiA8ORWYj9meUI",
  authDomain: "la-rockola-del-tiempo.firebaseapp.com",
  databaseURL: "https://la-rockola-del-tiempo-default-rtdb.firebaseio.com",
  projectId: "la-rockola-del-tiempo",
  storageBucket: "la-rockola-del-tiempo.firebasestorage.app",
  messagingSenderId: "1053145758148",
  appId: "1:1053145758148:web:3489a8b9bb14f2563c8c91"
};
