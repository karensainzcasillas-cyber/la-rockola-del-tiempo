# La Rockola del Tiempo · Salas multijugador

Esta entrega ya está conectada al proyecto Firebase `la-rockola-del-tiempo`.

## Publicar en Vercel

1. Descomprime el ZIP.
2. Sube la carpeta completa a Vercel como un nuevo deployment.
3. No cambies ni borres `firebase-config.js`.
4. Abre el enlace en dos celulares o en una ventana normal y otra incógnita.
5. En el primer dispositivo crea una sala.
6. En el segundo escribe otro nombre y el código de seis caracteres.
7. La anfitriona inicia cuando haya al menos dos jugadores.

## Reglas de Firebase

Para evitar que el modo de prueba caduque, abre Realtime Database > Rules y reemplaza el contenido por el archivo `firebase-rules.json`, después presiona Publish.

## Archivos

- `index.html`: interfaz.
- `styles.css`: diseño.
- `songs.js`: catálogo.
- `rooms.js`: salas, turnos y sincronización.
- `firebase-config.js`: conexión al proyecto Firebase.
- `firebase-rules.json`: reglas para Realtime Database.
